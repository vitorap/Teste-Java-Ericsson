package ap.vitor.testeEricsson;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TesteEricssonApplication {

	public static void main(String[] args) {
		SpringApplication.run(TesteEricssonApplication.class, args);
	}

}
